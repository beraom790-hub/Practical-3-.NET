﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;



namespace Practical_3

{

    internal class Program

    {

        static void Main(string[] args)

        {

            int ch;

            List<Expense> expenses = new List<Expense>();



            do

            {

                Console.WriteLine("	");

                Console.WriteLine("Expense Tracker Module"); Console.WriteLine("1. Add expense"); Console.WriteLine("2. View all Expense"); Console.WriteLine("3. View total expense"); Console.WriteLine("4. Exit"); Console.WriteLine("	");


                try

                {

                    Console.WriteLine("Enter Your Choise = "); ch = Convert.ToInt32(Console.ReadLine()); switch (ch)
                    {

                        case 1:

                            {



                                try

                                {

                                    Expense e = new Expense(); e.accDetails(); expenses.Add(e);
                                    Console.WriteLine("Expense Added Successsfully");

                                }

                                catch (FormatException)

                                {

                                    Console.WriteLine("Error : Please Enter a valid number");

                                }

                                catch (Exception ex)

                                {

                                    Console.WriteLine("Error : " + ex.Message);

                                }

                                finally

                                {

                                    Console.WriteLine("Expense Procssing Complete");

                                }



                                break;

                            }

                        case 2:

                            {

                                Console.WriteLine("All Expense"); if (expenses.Count == 0)
                                {

                                    Console.WriteLine("NO Expense Found");

                                }

                                else

                                {

                                    foreach (Expense ex in expenses)

                                    {

                                        ex.disDet();

                                    }

                                }

                                break;

                            }

                        case 3:



                            {

                                double t = 0;

                                foreach (Expense e in expenses) t = t + e.amt;
                                Console.WriteLine("Total Expense = Rs. " + t); break;
                            }

                        case 4:

                            {

                                Console.WriteLine("Thank you for using nomadic "); break;
                            }

                        default:

                            {

                                Console.WriteLine("INVALID choise"); break;
                            }

                    }



                }

                catch (FormatException)

                {

                    Console.WriteLine("Error : Please enter a valid menu choise"); ch = 0;
                }

            }
            while (ch != 4);

        }
        class Expense

        {

            public int expID; public string category; public double amt;
            public string paymentmode; public DateTime expDate;

            //method 1
            public void accDetails()
            {

                Console.Write("Enter Expense Id=");

                expID = Convert.ToInt32(Console.ReadLine()); Console.Write("Enter Expense Catagory="); category = Console.ReadLine(); Console.Write("Enter Expense Amount="); amt = Convert.ToDouble(Console.ReadLine());


                if (amt <= 0)

                {

                    throw new Exception("Expense must be greater than 0");

                }

                Console.Write("Enter Payment (Cash/UPI/Card)="); paymentmode = Console.ReadLine();


                expDate = DateTime.Now;

            }
            //method-2
            public void disDet()

            {

                Console.WriteLine("	");

                Console.WriteLine("Expense Id = " + expID); Console.WriteLine("Expense Category = " + category); Console.WriteLine("Amount = " + amt); Console.WriteLine("Payment Mode = " + paymentmode); Console.WriteLine("Date = " + expDate); Console.WriteLine("	");
            }

        }

    }

}

